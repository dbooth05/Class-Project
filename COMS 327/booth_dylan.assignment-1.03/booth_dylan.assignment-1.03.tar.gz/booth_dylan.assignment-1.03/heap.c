#include "heap.h"
#include <stdlib.h>

// int pqueue_init(struct pqueue *pq)
// {
//     pq->front = NULL;
//     pq->back = NULL;
//     pq->size = 0;

//     return 0;
// }
// int pqueue_destroy(struct pqueue *pq)
// {
//     struct pqueue_node *n;

//     for (n = pq->front; n; n = pq->front) {
//         pq->front = n->next;
//         free(n);
//     }

//     pq->back = NULL;
//     pq->size = 0;

//     return 0;
// }
// int pqueue_insert(struct pqueue *pq, double i, int x, int y)
// {
//     struct pqueue_node *n;

//     if (!(n = malloc(sizeof (struct pqueue_node)))) {
//         return -1;
//     }

//     if (!pq->front) {
//         pq->front = pq->back = n;
//         n->next = NULL;
//     } else {
//         n->next = pq->front;
//         pq->front = n;

//         // sort
//         while (n->next && (n->next->data < i)) {
//             n->data = n->next->data;
//             n->x = n->next->x;
//             n->y = n->next->y;
//             n = n->next;
//         }
//     }

//     n->data = i;
//     n->x = x;
//     n->y = y;

//     pq->size++;

//     return 0;
// }
// int pqueue_update(struct pqueue *pq, double i, int x, int y)
// {
//     struct pqueue_node *n;
//     struct pqueue_node *p;

//     if (pq->size == 1) {
//         if (pq->front->x == x && pq->front->y == y) {
//             pq->front->data = i;

//             return 0;
//         }
//          return -1;
//     }

//     for (n = pq->front; n; p = n, n = n->next) {
//         if (n->x == x && n->y == y) {
//             if (n == pq->front) {
//                 pq->front->data = i;
//                 return 0;
//             } else {
//                 if (n->next == pq->back) {
//                     pq->back = p;
//                 }
//                 p->next = n->next;
//                 pq->size--;
//                 free(n);
//                 pqueue_insert(pq, i, x, y);
//                 return 0;
//             }
//         }
//     }
//     return -1;
// }
// int pqueue_remove(struct pqueue *pq, double *i, int x, int y)
// {
//     struct pqueue_node *n;
//     struct pqueue_node *p;

//     if (!pq->front) {
//         return -1;
//     }
//     // If x or y or the signal values, pop from front
//     if (x == -1 || y == -1) {
//         n = pq->front;
//         if (i != NULL) {
//             *i = n->data;
//         }
//         if (!(pq->front = n->next)) {
//             pq->back = NULL;
//         }
//     } else {
//         for (n = pq->front; n; p = n, n = n->next) {
//             if (n->x == x && n->y == y) {
//                 if (p->next != NULL) {
//                     p->next = n->next;
//                 }
//                 if (n == pq->front) {
//                     pq->front = n->next;
//                 }
//                 if (n == pq->back) {
//                     pq->back = NULL;
//                 }
//                 break;
//             }
//         }
//         if (n->x != x || n->y != y) {
//             return -1;
//         }
//     }
//     pq->size--;

//     free(n);

//     return 0;
// }
// int pqueue_front(struct pqueue *pq, double *i)
// {
//     if (!pq->front) {
//         return -1;
//     }

//     *i = pq->front->data;

//     return 0;
// }
// int pqueue_size(struct pqueue *pq)
// {
//     return pq->size;
// }
// int is_empty(struct pqueue *pq)
// {
//     return !pq->size;
// }

minHeap *initHeap(int capacity) {
    minHeap *heap = (minHeap*)malloc(sizeof(minHeap));
    
    if (heap == NULL) {
        return NULL;
    }
    
    heap->size = 0;
    heap->cap = capacity;

    heap->arr = (tile**)malloc(capacity * sizeof(tile));

    return heap;
}

tile* createTile(int x, int y, int cost) {
    tile *t = (tile*)malloc(sizeof(tile));
    if (t) {
        t->x = x;
        t->y = y;
        t->cost = cost;
    }
    return t;
}

void swapNodes(tile **a, tile **b) {
    tile *tmp = *a;
    *a = *b;
    *b = tmp;
}

void minHeapify(minHeap *heap, int idx) {

    if (heap->size == 0) {
        return;
    }

    int left = idx * 2 + 1;
    int right = idx * 2 + 2;
    int min = idx;

    if (left < heap->size && heap->arr[left]->cost < heap->arr[min]->cost) {
        min = left;
    }
    if (right < heap->size && heap->arr[right]->cost < heap->arr[min]->cost) {
        min = right;
    }

    if (min != idx) {
        swapNodes(&heap->arr[idx], &heap->arr[min]);
        minHeapify(heap, min);
    }
}

int insert(minHeap *heap, tile *t) {
    if (heap->size == heap->cap) {
        return 0;
    }

    int idx = heap->size;
    heap->arr[idx] = t;
    heap->size++;

    while (idx > 0 && heap->arr[(idx - 1) / 2]->cost > heap->arr[idx]->cost) {
        swapNodes(&heap->arr[idx], &heap->arr[(idx - 1) / 2]);
        idx = (idx - 1) / 2;
    }

    return 1;
}

tile *extractMin(minHeap *heap) {
    if (heap->size == 0) {
        return NULL;
    }

    tile *root = heap->arr[0];
    tile *last = heap->arr[heap->size - 1];

    heap->arr[0] = last;
    heap->size--;

    minHeapify(heap, 0);

    return root;
}

void decreaseKey(minHeap *heap, int idx) {
    
    if (idx > heap->size) {
        return;
    }

    // heap->arr[idx]->key = newKey;

    // while (idx > 0 && heap->arr[(idx - 1) / 2]->key > heap->arr[idx]->key) {
    //     swapNodes(&heap->arr[idx], &heap->arr[(idx - 1) / 2]);
    //     idx = (idx - 1) / 2;
    // }
}

int heapEmpty(minHeap *heap) {
    return (heap->size == 0);
}

void destroyHeap(minHeap *heap) {
    free(heap->arr);
    free(heap);
}

